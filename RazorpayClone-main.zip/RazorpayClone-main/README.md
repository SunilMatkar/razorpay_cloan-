# RazorpayClone
This Website used <b>HTML</b> and <b>Tailwind CSS</b>

![Screenshot of RazorpayClone](https://user-images.githubusercontent.com/96276958/231836765-32cf87c8-5ade-4b9e-97a7-455546aee86b.png)
